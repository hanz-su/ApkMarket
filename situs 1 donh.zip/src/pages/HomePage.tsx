import { useState } from 'react';
import { Hero } from '@/components/features/Hero';
import { ProductGrid } from '@/components/features/ProductGrid';
import { CategoryNav } from '@/components/layout/CategoryNav';
import { products } from '@/constants/products';

export function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const filteredProducts = selectedCategory === 'all'
    ? products
    : products.filter(product => product.category === selectedCategory);

  console.log('Selected category:', selectedCategory);
  console.log('Filtered products count:', filteredProducts.length);

  return (
    <div className="min-h-screen">
      <Hero />
      
      <CategoryNav 
        selectedCategory={selectedCategory}
        onCategoryChange={setSelectedCategory}
      />

      <div className="container-custom py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">
            {selectedCategory === 'all' ? 'Semua Produk' : 'Produk Pilihan'}
          </h2>
          <p className="text-muted-foreground">
            {filteredProducts.length} produk ditemukan
          </p>
        </div>

        <ProductGrid products={filteredProducts} />
      </div>
    </div>
  );
}
