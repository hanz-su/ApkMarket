import { Sun, Facebook, Instagram, Twitter } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-muted border-t mt-16">
      <div className="container-custom py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-hero-gradient">
                <Sun className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-clip-text text-transparent bg-hero-gradient">
                Cerah Market
              </span>
            </div>
            <p className="text-muted-foreground mb-4 max-w-md">
              Platform belanja online terpercaya dengan ribuan produk berkualitas. 
              Belanja mudah, aman, dan terpercaya dengan harga terbaik.
            </p>
            <div className="flex gap-3">
              <a href="#" className="p-2 rounded-full bg-background hover:bg-primary hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="p-2 rounded-full bg-background hover:bg-primary hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="p-2 rounded-full bg-background hover:bg-primary hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div>
            <h3 className="font-semibold mb-4">Tentang Kami</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Tentang Cerah Market</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Kebijakan Privasi</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Syarat & Ketentuan</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Hubungi Kami</a></li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-4">Bantuan</h3>
            <ul className="space-y-2 text-muted-foreground">
              <li><a href="#" className="hover:text-primary transition-colors">Cara Berbelanja</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Pembayaran</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Pengiriman</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Pengembalian</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-muted-foreground text-sm">
          <p>&copy; 2024 Cerah Market. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
