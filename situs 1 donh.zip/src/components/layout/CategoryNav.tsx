import { categories } from '@/constants/products';
import { Button } from '@/components/ui/button';
import { 
  Laptop, 
  ShoppingBag, 
  UtensilsCrossed, 
  Sparkles, 
  Dumbbell, 
  Home 
} from 'lucide-react';

const iconMap = {
  Laptop,
  ShoppingBag,
  UtensilsCrossed,
  Sparkles,
  Dumbbell,
  Home,
};

interface CategoryNavProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export function CategoryNav({ selectedCategory, onCategoryChange }: CategoryNavProps) {
  return (
    <div className="border-b bg-card">
      <div className="container-custom">
        <div className="flex gap-2 overflow-x-auto py-4 scrollbar-hide">
          <Button
            variant={selectedCategory === 'all' ? 'default' : 'outline'}
            onClick={() => onCategoryChange('all')}
            className="whitespace-nowrap"
          >
            Semua Kategori
          </Button>
          {categories.map((category) => {
            const Icon = iconMap[category.icon as keyof typeof iconMap];
            return (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? 'default' : 'outline'}
                onClick={() => onCategoryChange(category.id)}
                className="whitespace-nowrap gap-2"
              >
                <Icon className="h-4 w-4" />
                {category.name}
              </Button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
