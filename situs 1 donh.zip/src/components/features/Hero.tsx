import { Button } from '@/components/ui/button';
import { ShoppingBag, TrendingUp, Shield, Zap } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative overflow-hidden bg-hero-gradient py-16 md:py-24">
      <div className="absolute inset-0 bg-grid-white/10 bg-[size:20px_20px]" />
      
      <div className="container-custom relative">
        <div className="flex flex-col items-center text-center">
          <div className="animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Belanja Mudah di
              <br />
              <span className="text-white/90">Cerah Market</span>
            </h1>
            <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto">
              Temukan ribuan produk berkualitas dengan harga terbaik. 
              Belanja aman, cepat, dan terpercaya.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 gap-2">
                <ShoppingBag className="h-5 w-5" />
                Mulai Belanja
              </Button>
              <Button size="lg" variant="outline" className="bg-white/10 text-white border-white/20 hover:bg-white/20">
                Lihat Promo
              </Button>
            </div>
          </div>

          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 w-full max-w-4xl">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-white animate-slide-up">
              <TrendingUp className="h-8 w-8 mb-3 mx-auto" />
              <h3 className="font-semibold mb-2">Harga Terbaik</h3>
              <p className="text-sm text-white/80">Dapatkan diskon hingga 70% setiap hari</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-white animate-slide-up" style={{ animationDelay: '0.1s' }}>
              <Shield className="h-8 w-8 mb-3 mx-auto" />
              <h3 className="font-semibold mb-2">100% Aman</h3>
              <p className="text-sm text-white/80">Pembayaran dan transaksi terjamin</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 text-white animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <Zap className="h-8 w-8 mb-3 mx-auto" />
              <h3 className="font-semibold mb-2">Pengiriman Cepat</h3>
              <p className="text-sm text-white/80">Sampai di tangan dalam 1-3 hari</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
