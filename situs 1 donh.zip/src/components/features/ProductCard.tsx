import { Product } from '@/types/product';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { ShoppingCart, Star } from 'lucide-react';
import { useCartStore } from '@/stores/cartStore';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const addToCart = useCartStore((state) => state.addToCart);
  const { toast } = useToast();

  const handleAddToCart = () => {
    addToCart(product);
    toast({
      title: 'Berhasil ditambahkan!',
      description: `${product.name} telah ditambahkan ke keranjang`,
    });
    console.log('Product added to cart:', product.name);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  return (
    <Card className="product-card group">
      <div className="relative overflow-hidden aspect-square">
        <img
          src={product.image}
          alt={product.name}
          className="object-cover w-full h-full group-hover:scale-110 transition-transform duration-300"
        />
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {product.isNew && (
            <span className="badge-new">BARU</span>
          )}
          {product.discount && (
            <span className="badge-discount">{product.discount}% OFF</span>
          )}
        </div>
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-sm md:text-base line-clamp-2 mb-2 text-card-foreground">
          {product.name}
        </h3>

        <div className="flex items-center gap-1 mb-2">
          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
          <span className="text-sm font-medium text-muted-foreground">
            {product.rating}
          </span>
          <span className="text-xs text-muted-foreground ml-1">
            ({product.sold} terjual)
          </span>
        </div>

        <div className="mb-3">
          {product.originalPrice ? (
            <>
              <div className="text-xs text-muted-foreground line-through">
                {formatPrice(product.originalPrice)}
              </div>
              <div className="text-lg font-bold text-primary">
                {formatPrice(product.price)}
              </div>
            </>
          ) : (
            <div className="text-lg font-bold text-primary">
              {formatPrice(product.price)}
            </div>
          )}
        </div>

        <Button 
          onClick={handleAddToCart}
          className="w-full gap-2"
          size="sm"
        >
          <ShoppingCart className="h-4 w-4" />
          Tambah ke Keranjang
        </Button>
      </div>
    </Card>
  );
}
